.. py:currentmodule:: nodeeditor.node_graphics_scene

:py:mod:`node\_graphics\_scene` Module
=======================================

.. automodule:: nodeeditor.node_graphics_scene
    :members:
    :undoc-members:
    :show-inheritance:
