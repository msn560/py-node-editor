.. py:currentmodule:: nodeeditor.node_content_widget

:py:mod:`node\_content\_widget` Module
=======================================

.. automodule:: nodeeditor.node_content_widget

.. autoclass:: QDMNodeContentWidget
    :members:
    :undoc-members:
    :show-inheritance:


.. autoclass:: QDMTextEdit
    :members:
    :undoc-members:
    :show-inheritance:

