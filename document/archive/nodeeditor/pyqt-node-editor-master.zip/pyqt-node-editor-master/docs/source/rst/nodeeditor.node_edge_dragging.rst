.. py:currentmodule:: nodeeditor.node_edge_dragging

:py:mod:`node\_edge\_dragging` Module
=====================================

.. automodule:: nodeeditor.node_edge_dragging
    :members:
    :undoc-members:
    :show-inheritance:
