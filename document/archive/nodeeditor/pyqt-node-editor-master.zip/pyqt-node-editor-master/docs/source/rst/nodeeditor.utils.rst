.. py:currentmodule:: nodeeditor.utils

:py:mod:`utils` Module
=======================


.. automodule:: nodeeditor.utils
    :members:
    :undoc-members:
    :show-inheritance:

    .. autofunction:: nodeeditor.utils.pp

        Shortcut function for ``PrettyPrinter.pprint()`` method. Already instantiated and
        with indentation set to 4 spaces
