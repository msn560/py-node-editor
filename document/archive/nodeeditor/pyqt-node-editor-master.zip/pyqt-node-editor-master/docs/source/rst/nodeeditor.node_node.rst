.. py:currentmodule:: nodeeditor.node_node

:py:mod:`node\_node` Module
============================

.. automodule:: nodeeditor.node_node


.. autoclass:: Node
    :members:
    :undoc-members:
    :show-inheritance:
