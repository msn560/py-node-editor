    `History Modified`
        after `History Stamp` has been stored or restored
    `History Stored`
        after `History Stamp` has been stored
    `History Restored`
        after `History Stamp` has been restored