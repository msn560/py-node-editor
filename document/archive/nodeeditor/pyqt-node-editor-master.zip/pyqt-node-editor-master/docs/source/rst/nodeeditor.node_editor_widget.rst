.. py:currentmodule:: nodeeditor.node_edgitor_widget

:py:mod:`node\_editor\_widget` Module
======================================

.. automodule:: nodeeditor.node_editor_widget
    :members:
    :undoc-members:
    :show-inheritance:
