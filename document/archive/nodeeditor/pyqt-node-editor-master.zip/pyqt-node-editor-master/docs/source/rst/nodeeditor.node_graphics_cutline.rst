.. py:currentmodule:: nodeeditor.node_graphics_cutline

:py:mod:`node\_graphics\_cutline` Module
=========================================

.. automodule:: nodeeditor.node_graphics_cutline
    :members:
    :undoc-members:
    :show-inheritance:
